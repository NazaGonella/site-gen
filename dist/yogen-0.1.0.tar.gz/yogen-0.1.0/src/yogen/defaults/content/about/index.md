---
title: About
author: Your Name
date: 11/11/11
tags: about
section: about
template: template-home
---

<div style="margin-top:2em;"></div>

<center>
Hello, this is your about page.
</center>

<div style="margin-bottom:2em;"></div>

---

**Email**
: [youremail@example.com](/about/)

**GitHub**  
: [github.com/example](/about/)

**LinkedIn**  
: [linkedin.com/in/example](/about/)

---
